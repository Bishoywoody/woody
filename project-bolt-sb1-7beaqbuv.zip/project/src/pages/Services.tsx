import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Code, 
  Smartphone, 
  Megaphone, 
  Headphones, 
  BarChart3, 
  Cloud,
  CheckCircle,
  ArrowLeft,
  Star,
  Zap,
  Shield,
  Users
} from 'lucide-react';

const Services = () => {
  const services = [
    {
      icon: Code,
      title: 'تصميم المواقع',
      description: 'تصميم مواقع ويب احترافية وجذابة تلبي احتياجات عملك وتعكس هوية علامتك التجارية، مع ضمان تجربة مستخدم ممتازة.',
      features: ['تصميم متجاوب لجميع الأجهزة', 'واجهة مستخدم سهلة الاستخدام', 'تحسين لمحركات البحث'],
      popular: true,
      image: 'https://images.unsplash.com/photo-1467232004584-a241de8bcf5d?auto=format&fit=crop&w=600&q=80'
    },
    {
      icon: Smartphone,
      title: 'تطوير التطبيقات',
      description: 'تطوير تطبيقات مخصصة لنظامي iOS و Android بجودة عالية وأداء ممتاز، مع ضمان التوافق مع أحدث إصدارات الأنظمة.',
      features: ['تطبيقات أصلية ومختلطة', 'واجهات سهلة الاستخدام', 'تكامل مع أنظمة الشركة'],
      popular: false,
      image: 'https://images.unsplash.com/photo-1512941937669-90a1b58e7e9c?auto=format&fit=crop&w=600&q=80'
    },
    {
      icon: Megaphone,
      title: 'التسويق الرقمي',
      description: 'حلول تسويقية متكاملة تشمل إدارة الحملات الإعلانية وتحسين محركات البحث والتسويق عبر وسائل التواصل الاجتماعي.',
      features: ['إعلانات جوجل وفيسبوك', 'تحسين محركات البحث (SEO)', 'إدارة وسائل التواصل الاجتماعي'],
      popular: true,
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=600&q=80'
    },
    {
      icon: Headphones,
      title: 'الاستشارات التقنية',
      description: 'استشارات تقنية متخصصة تساعدك في اتخاذ القرارات الصحيحة لتطوير بنيتك التحتية التقنية وتحسين عملياتك الرقمية.',
      features: ['تحليل احتياجات الأعمال', 'تقييم البنية التحتية', 'خطط التحول الرقمي'],
      popular: false,
      image: 'https://images.unsplash.com/photo-1553877522-43269d4ea984?auto=format&fit=crop&w=600&q=80'
    },
    {
      icon: BarChart3,
      title: 'تحليل البيانات',
      description: 'تحليل البيانات واستخراج الرؤى القيمة لمساعدتك في اتخاذ قرارات أعمال مدعومة بالبيانات وتحسين أداء شركتك.',
      features: ['تحليل البيانات الضخمة', 'لوحات تحكم تفاعلية', 'تقارير مخصصة'],
      popular: false,
      image: 'https://images.unsplash.com/photo-1551288049-bebda4e38f71?auto=format&fit=crop&w=600&q=80'
    },
    {
      icon: Cloud,
      title: 'الحلول السحابية',
      description: 'حلول سحابية متكاملة تشمل الهجرة إلى السحابة وإدارة البنية التحتية السحابية وتطبيقات البرمجيات كخدمة (SaaS).',
      features: ['هجرة الأنظمة إلى السحابة', 'إدارة البنية التحتية', 'حلول الأمان السحابي'],
      popular: false,
      new: true,
      image: 'https://images.unsplash.com/photo-1451187580459-43490279c0fa?auto=format&fit=crop&w=600&q=80'
    }
  ];

  const process = [
    { step: 1, title: 'الاستماع', description: 'نستمع بعناية لمتطلباتك وأهدافك لفهم احتياجاتك بدقة' },
    { step: 2, title: 'التخطيط', description: 'نضع خطة عمل مفصلة تحقق أهدافك ضمن الميزانية والوقت' },
    { step: 3, title: 'التنفيذ', description: 'ننفذ الحلول باحترافية مع تحديثك بانتظام عن التقدم' },
    { step: 4, title: 'التسليم', description: 'نسلم المشروع مع دعم كامل وضمان الجودة' }
  ];

  const benefits = [
    { icon: Zap, title: 'سرعة في التنفيذ', description: 'نلتزم بالمواعيد ونسلم في الوقت المحدد' },
    { icon: Shield, title: 'جودة مضمونة', description: 'نطبق أعلى معايير الجودة في العمل' },
    { icon: Users, title: 'دعم مستمر', description: 'فريق دعم متاح على مدار الساعة' }
  ];

  return (
    <div className="pt-20">
      {/* Page Header */}
      <section className="gradient-bg text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">خدماتنا المتميزة</h1>
            <p className="text-xl text-gray-100">
              اكتشف مجموعة الخدمات الاحترافية التي نقدمها لمساعدتك في تحقيق أهداف عملك
            </p>
          </div>
        </div>
      </section>

      {/* Services Overview */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">حلول متكاملة لاحتياجات عملك</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              نقدم مجموعة واسعة من الخدمات الاحترافية المصممة خصيصًا لمساعدتك في تحقيق أهداف عملك وتطوير حضورك الرقمي
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-lg card-hover group">
                <div className="relative">
                  <img 
                    src={service.image} 
                    alt={service.title} 
                    className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute top-4 right-4 flex gap-2">
                    {service.popular && (
                      <span className="bg-primary-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                        شائع
                      </span>
                    )}
                    {service.new && (
                      <span className="bg-green-600 text-white px-3 py-1 rounded-full text-sm font-medium">
                        جديد
                      </span>
                    )}
                  </div>
                </div>
                
                <div className="p-6">
                  <div className="flex items-center mb-4">
                    <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center mr-4 group-hover:bg-primary-600 transition-colors duration-300">
                      <service.icon className="w-6 h-6 text-primary-600 group-hover:text-white transition-colors duration-300" />
                    </div>
                    <h3 className="text-xl font-bold text-gray-800">{service.title}</h3>
                  </div>
                  
                  <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                  
                  <ul className="space-y-2 mb-6">
                    {service.features.map((feature, idx) => (
                      <li key={idx} className="flex items-center text-gray-600">
                        <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                        <span className="text-sm">{feature}</span>
                      </li>
                    ))}
                  </ul>
                  
                  <Link 
                    to="/contact" 
                    className="text-primary-600 font-medium hover:text-primary-700 inline-flex items-center group-hover:translate-x-1 transition-transform duration-300"
                  >
                    طلب الخدمة
                    <ArrowLeft className="w-4 h-4 mr-2" />
                  </Link>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Process */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">كيف نعمل</h2>
            <p className="text-xl text-gray-600">منهجية عمل مدروسة لضمان نجاح مشروعك</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {process.map((step, index) => (
              <div key={index} className="text-center group">
                <div className="relative mb-6">
                  <div className="w-20 h-20 bg-white rounded-full flex items-center justify-center mx-auto shadow-lg group-hover:shadow-xl transition-shadow duration-300">
                    <span className="text-2xl font-bold text-primary-600">{step.step}</span>
                  </div>
                  {index < process.length - 1 && (
                    <div className="hidden lg:block absolute top-10 left-full w-full h-0.5 bg-primary-200 -translate-x-1/2"></div>
                  )}
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-3">{step.title}</h3>
                <p className="text-gray-600 leading-relaxed">{step.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">لماذا تختار خدماتنا؟</h2>
            <p className="text-xl text-gray-600">المزايا التي تحصل عليها عند التعامل معنا</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            {benefits.map((benefit, index) => (
              <div key={index} className="text-center group">
                <div className="w-20 h-20 bg-primary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-primary-600 transition-colors duration-300">
                  <benefit.icon className="w-10 h-10 text-primary-600 group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">{benefit.title}</h3>
                <p className="text-gray-600 leading-relaxed">{benefit.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Testimonial */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto text-center">
            <div className="bg-white rounded-2xl p-8 shadow-lg">
              <div className="flex justify-center mb-6">
                {[...Array(5)].map((_, i) => (
                  <Star key={i} className="w-6 h-6 text-yellow-400 fill-current" />
                ))}
              </div>
              <blockquote className="text-2xl text-gray-800 font-medium mb-6 leading-relaxed">
                "فريق محترف ومتميز، تم تسليم مشروعنا في الوقت المحدد وبجودة تفوق التوقعات. 
                أنصح بالتعامل معهم لأي شركة تبحث عن حلول تقنية موثوقة."
              </blockquote>
              <div className="flex items-center justify-center">
                <img 
                  src="https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=100&q=80" 
                  alt="عميل راضي" 
                  className="w-16 h-16 rounded-full mr-4"
                />
                <div className="text-right">
                  <div className="font-bold text-gray-800">أحمد محمد</div>
                  <div className="text-gray-600">مدير عام، شركة التقنية المتقدمة</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">هل لديك مشروع في ذهنك؟</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-gray-100">
            اتصل بنا اليوم واحصل على استشارة مجانية حول كيفية تحويل فكرتك إلى واقع رقمي
          </p>
          <Link to="/contact" className="btn-secondary inline-flex items-center">
            احصل على استشارة مجانية
            <ArrowLeft className="w-5 h-5 mr-2" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default Services;