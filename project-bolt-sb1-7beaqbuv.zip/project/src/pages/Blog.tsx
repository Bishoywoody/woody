import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Calendar, 
  User, 
  ArrowLeft, 
  Search, 
  Tag,
  TrendingUp,
  Clock
} from 'lucide-react';

const Blog = () => {
  const featuredPost = {
    title: 'أهم اتجاهات التكنولوجيا في 2024',
    excerpt: 'استكشف معنا أهم الاتجاهات التكنولوجية التي ستشكل مستقبل الأعمال والصناعات في العام الحالي وكيف يمكنك الاستفادة منها.',
    image: 'https://images.unsplash.com/photo-1518709268805-4e9042af2176?auto=format&fit=crop&w=800&q=80',
    date: '15 مايو 2024',
    author: 'فريق التحرير',
    readTime: '5 دقائق',
    category: 'تكنولوجيا'
  };

  const posts = [
    {
      title: 'أساسيات تصميم تجربة المستخدم',
      excerpt: 'تعرف على المبادئ الأساسية لتصميم تجربة مستخدم ممتازة وكيفية تطبيقها في مشاريعك.',
      image: 'https://images.unsplash.com/photo-1561070791-2526d30994b5?auto=format&fit=crop&w=400&q=80',
      date: '10 أبريل 2024',
      author: 'سارة محمد',
      readTime: '7 دقائق',
      category: 'تصميم'
    },
    {
      title: 'أفضل ممارسات تحسين محركات البحث',
      excerpt: 'دليل شامل لأفضل الممارسات التي يجب اتباعها لتحسين ظهور موقعك في نتائج البحث.',
      image: 'https://images.unsplash.com/photo-1432888622747-4eb9a8efeb07?auto=format&fit=crop&w=400&q=80',
      date: '25 مارس 2024',
      author: 'أحمد خالد',
      readTime: '6 دقائق',
      category: 'تسويق'
    },
    {
      title: 'نصائح أساسية لأمن المعلومات',
      excerpt: 'كيف تحمي بياناتك وبيانات عملائك من التهديدات الأمنية المتزايدة في العالم الرقمي.',
      image: 'https://images.unsplash.com/photo-1563013544-824ae1b704d3?auto=format&fit=crop&w=400&q=80',
      date: '5 مارس 2024',
      author: 'خالد عبدالله',
      readTime: '8 دقائق',
      category: 'أمان'
    },
    {
      title: 'استراتيجيات ناجحة للتسويق بالمحتوى',
      excerpt: 'كيفية بناء استراتيجية تسويق محتوى فعالة تجذب العملاء وتزيد من مبيعاتك.',
      image: 'https://images.unsplash.com/photo-1504868584819-f8e8b4b6d7e3?auto=format&fit=crop&w=400&q=80',
      date: '18 فبراير 2024',
      author: 'نورة سعيد',
      readTime: '9 دقائق',
      category: 'تسويق'
    },
    {
      title: 'مستقبل الذكاء الاصطناعي في الأعمال',
      excerpt: 'كيف يمكن للذكاء الاصطناعي أن يحول طريقة عمل الشركات ويحسن من كفاءتها.',
      image: 'https://images.unsplash.com/photo-1485827404703-89b55fcc595e?auto=format&fit=crop&w=400&q=80',
      date: '2 فبراير 2024',
      author: 'فريق التحرير',
      readTime: '10 دقائق',
      category: 'ذكاء اصطناعي'
    },
    {
      title: 'أدوات أساسية لكل مطور ويب',
      excerpt: 'مجموعة من الأدوات والمكتبات التي يحتاجها كل مطور ويب لتحسين إنتاجيته.',
      image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=400&q=80',
      date: '20 يناير 2024',
      author: 'أحمد خالد',
      readTime: '6 دقائق',
      category: 'تطوير'
    }
  ];

  const categories = [
    { name: 'تصميم المواقع', count: 12 },
    { name: 'تطوير التطبيقات', count: 8 },
    { name: 'التسويق الرقمي', count: 15 },
    { name: 'أمن المعلومات', count: 5 },
    { name: 'الذكاء الاصطناعي', count: 7 },
    { name: 'تحليل البيانات', count: 9 }
  ];

  const recentPosts = [
    {
      title: 'كيفية اختيار استضافة الويب المناسبة',
      date: '2 مايو 2024',
      image: 'https://images.unsplash.com/photo-1558494949-ef010cbdcc31?auto=format&fit=crop&w=80&q=80'
    },
    {
      title: 'أدوات أساسية لكل مطور ويب',
      date: '20 أبريل 2024',
      image: 'https://images.unsplash.com/photo-1461749280684-dccba630e2f6?auto=format&fit=crop&w=80&q=80'
    },
    {
      title: 'تحسين أداء مواقع الويب',
      date: '5 أبريل 2024',
      image: 'https://images.unsplash.com/photo-1460925895917-afdab827c52f?auto=format&fit=crop&w=80&q=80'
    }
  ];

  const tags = [
    'تصميم', 'تطوير', 'SEO', 'أمن', 'تسويق', 'برمجة', 'ويب', 'تطبيقات', 'UI/UX', 'JavaScript'
  ];

  return (
    <div className="pt-20">
      {/* Page Header */}
      <section className="gradient-bg text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">المدونة</h1>
            <p className="text-xl text-gray-100">
              آخر المقالات والأخبار حول التكنولوجيا وتطوير الأعمال
            </p>
          </div>
        </div>
      </section>

      {/* Blog Content */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-12">
            {/* Main Content */}
            <div className="lg:col-span-2">
              {/* Featured Post */}
              <div className="mb-16">
                <div className="bg-white rounded-2xl overflow-hidden shadow-xl card-hover">
                  <div className="relative">
                    <img 
                      src={featuredPost.image} 
                      alt={featuredPost.title} 
                      className="w-full h-64 md:h-80 object-cover"
                    />
                    <div className="absolute top-6 right-6">
                      <span className="bg-primary-600 text-white px-4 py-2 rounded-full text-sm font-medium">
                        مميز
                      </span>
                    </div>
                  </div>
                  <div className="p-8">
                    <div className="flex items-center gap-4 mb-4 text-sm text-gray-500">
                      <span className="bg-primary-100 text-primary-600 px-3 py-1 rounded-full font-medium">
                        {featuredPost.category}
                      </span>
                      <div className="flex items-center gap-1">
                        <Calendar className="w-4 h-4" />
                        {featuredPost.date}
                      </div>
                      <div className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {featuredPost.readTime}
                      </div>
                    </div>
                    <h2 className="text-3xl font-bold text-gray-800 mb-4">{featuredPost.title}</h2>
                    <p className="text-gray-600 mb-6 leading-relaxed text-lg">{featuredPost.excerpt}</p>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <User className="w-5 h-5 text-gray-400" />
                        <span className="text-gray-600">{featuredPost.author}</span>
                      </div>
                      <Link 
                        to="#" 
                        className="text-primary-600 font-medium hover:text-primary-700 inline-flex items-center group"
                      >
                        اقرأ المزيد
                        <ArrowLeft className="w-4 h-4 mr-2 group-hover:translate-x-1 transition-transform duration-300" />
                      </Link>
                    </div>
                  </div>
                </div>
              </div>
              
              {/* Blog Posts Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-12">
                {posts.map((post, index) => (
                  <article key={index} className="bg-white rounded-2xl overflow-hidden shadow-lg card-hover group">
                    <div className="relative overflow-hidden">
                      <img 
                        src={post.image} 
                        alt={post.title} 
                        className="w-full h-48 object-cover group-hover:scale-110 transition-transform duration-300"
                      />
                      <div className="absolute top-4 right-4">
                        <span className="bg-white/90 text-gray-800 px-3 py-1 rounded-full text-xs font-medium">
                          {post.category}
                        </span>
                      </div>
                    </div>
                    <div className="p-6">
                      <div className="flex items-center gap-4 mb-3 text-xs text-gray-500">
                        <div className="flex items-center gap-1">
                          <Calendar className="w-3 h-3" />
                          {post.date}
                        </div>
                        <div className="flex items-center gap-1">
                          <Clock className="w-3 h-3" />
                          {post.readTime}
                        </div>
                      </div>
                      <h3 className="text-xl font-bold text-gray-800 mb-3 group-hover:text-primary-600 transition-colors duration-300">
                        {post.title}
                      </h3>
                      <p className="text-gray-600 mb-4 leading-relaxed text-sm">{post.excerpt}</p>
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2 text-sm text-gray-500">
                          <User className="w-4 h-4" />
                          {post.author}
                        </div>
                        <Link 
                          to="#" 
                          className="text-primary-600 font-medium hover:text-primary-700 inline-flex items-center text-sm group"
                        >
                          اقرأ المزيد
                          <ArrowLeft className="w-3 h-3 mr-2 group-hover:translate-x-1 transition-transform duration-300" />
                        </Link>
                      </div>
                    </div>
                  </article>
                ))}
              </div>
              
              {/* Pagination */}
              <div className="flex justify-center">
                <nav className="flex items-center gap-2">
                  <button className="px-4 py-2 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors duration-300">
                    السابق
                  </button>
                  <button className="px-4 py-2 bg-primary-600 text-white rounded-lg font-medium">1</button>
                  <button className="px-4 py-2 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors duration-300">2</button>
                  <button className="px-4 py-2 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors duration-300">3</button>
                  <button className="px-4 py-2 border border-gray-300 rounded-lg text-gray-600 hover:bg-gray-100 transition-colors duration-300">
                    التالي
                  </button>
                </nav>
              </div>
            </div>
            
            {/* Sidebar */}
            <div className="space-y-8">
              {/* Search */}
              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-gray-800 mb-4">بحث</h3>
                <form className="flex">
                  <input
                    type="text"
                    placeholder="ابحث في المقالات..."
                    className="flex-1 px-4 py-3 border border-gray-300 rounded-r-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent"
                  />
                  <button
                    type="submit"
                    className="bg-primary-600 text-white px-4 py-3 rounded-l-lg hover:bg-primary-700 transition-colors duration-300"
                  >
                    <Search className="w-5 h-5" />
                  </button>
                </form>
              </div>
              
              {/* Categories */}
              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-gray-800 mb-6">التصنيفات</h3>
                <ul className="space-y-3">
                  {categories.map((category, index) => (
                    <li key={index}>
                      <Link 
                        to="#" 
                        className="flex justify-between items-center text-gray-600 hover:text-primary-600 transition-colors duration-300 group"
                      >
                        <span className="group-hover:translate-x-1 transition-transform duration-300">
                          {category.name}
                        </span>
                        <span className="bg-gray-100 group-hover:bg-primary-100 text-gray-600 group-hover:text-primary-600 px-2 py-1 rounded-full text-xs font-medium transition-colors duration-300">
                          {category.count}
                        </span>
                      </Link>
                    </li>
                  ))}
                </ul>
              </div>
              
              {/* Recent Posts */}
              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-gray-800 mb-6">أحدث المقالات</h3>
                <div className="space-y-4">
                  {recentPosts.map((post, index) => (
                    <div key={index} className="flex gap-4 group">
                      <img 
                        src={post.image} 
                        alt={post.title} 
                        className="w-16 h-16 object-cover rounded-lg flex-shrink-0"
                      />
                      <div className="flex-1">
                        <h4 className="font-bold text-gray-800 mb-1 group-hover:text-primary-600 transition-colors duration-300 leading-tight">
                          <Link to="#" className="hover:underline">
                            {post.title}
                          </Link>
                        </h4>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <Calendar className="w-3 h-3" />
                          {post.date}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
              
              {/* Tags */}
              <div className="bg-white p-6 rounded-2xl shadow-lg">
                <h3 className="text-xl font-bold text-gray-800 mb-6">الكلمات المفتاحية</h3>
                <div className="flex flex-wrap gap-2">
                  {tags.map((tag, index) => (
                    <Link
                      key={index}
                      to="#"
                      className="bg-gray-100 text-gray-600 px-3 py-2 rounded-full text-sm hover:bg-primary-600 hover:text-white transition-colors duration-300"
                    >
                      #{tag}
                    </Link>
                  ))}
                </div>
              </div>
              
              {/* Newsletter */}
              <div className="bg-gradient-to-br from-primary-600 to-secondary-600 p-6 rounded-2xl text-white">
                <h3 className="text-xl font-bold mb-4">اشترك في النشرة البريدية</h3>
                <p className="text-primary-100 mb-6 text-sm">
                  احصل على آخر المقالات والأخبار مباشرة إلى بريدك الإلكتروني
                </p>
                <form className="space-y-3">
                  <input
                    type="email"
                    placeholder="بريدك الإلكتروني"
                    className="w-full px-4 py-3 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-white/50"
                  />
                  <button
                    type="submit"
                    className="w-full bg-white text-primary-600 py-3 rounded-lg font-medium hover:bg-gray-100 transition-colors duration-300"
                  >
                    اشتراك
                  </button>
                </form>
              </div>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Blog;