import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  Send,
  CheckCircle,
  Facebook,
  Twitter,
  Linkedin,
  Instagram
} from 'lucide-react';

const Contact = () => {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });
  const [isSubmitted, setIsSubmitted] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement | HTMLSelectElement>) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    });
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Handle form submission here
    setIsSubmitted(true);
    setTimeout(() => setIsSubmitted(false), 3000);
  };

  const contactInfo = [
    {
      icon: MapPin,
      title: 'العنوان',
      details: ['123 شارع الأعمال، الرياض', 'المملكة العربية السعودية']
    },
    {
      icon: Phone,
      title: 'الهاتف',
      details: ['+966 12 345 6789', '+966 98 765 4321']
    },
    {
      icon: Mail,
      title: 'البريد الإلكتروني',
      details: ['info@example.com', 'support@example.com']
    },
    {
      icon: Clock,
      title: 'ساعات العمل',
      details: ['الأحد - الخميس: 8 صباحًا - 5 مساءً', 'الجمعة والسبت: إجازة']
    }
  ];

  const socialLinks = [
    { icon: Facebook, href: '#', label: 'فيسبوك', color: 'hover:text-blue-600' },
    { icon: Twitter, href: '#', label: 'تويتر', color: 'hover:text-blue-400' },
    { icon: Linkedin, href: '#', label: 'لينكد إن', color: 'hover:text-blue-700' },
    { icon: Instagram, href: '#', label: 'إنستغرام', color: 'hover:text-pink-600' }
  ];

  return (
    <div className="pt-20">
      {/* Page Header */}
      <section className="gradient-bg text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">تواصل معنا</h1>
            <p className="text-xl text-gray-100">
              نحن هنا لمساعدتك والإجابة على جميع استفساراتك
            </p>
          </div>
        </div>
      </section>

      {/* Contact Content */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
            {/* Contact Form */}
            <div className="bg-white p-8 rounded-2xl shadow-xl">
              <h2 className="text-3xl font-bold text-gray-800 mb-6">أرسل لنا رسالة</h2>
              <p className="text-gray-600 mb-8">
                املأ النموذج أدناه وسنتواصل معك في أقرب وقت ممكن
              </p>
              
              {isSubmitted && (
                <div className="mb-6 p-4 bg-green-50 border border-green-200 rounded-lg flex items-center gap-3">
                  <CheckCircle className="w-5 h-5 text-green-600" />
                  <span className="text-green-800">تم إرسال رسالتك بنجاح! سنتواصل معك قريباً.</span>
                </div>
              )}
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="name" className="block text-gray-700 font-medium mb-2">
                      الاسم الكامل *
                    </label>
                    <input
                      type="text"
                      id="name"
                      name="name"
                      value={formData.name}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all duration-300"
                      placeholder="أدخل اسمك الكامل"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="email" className="block text-gray-700 font-medium mb-2">
                      البريد الإلكتروني *
                    </label>
                    <input
                      type="email"
                      id="email"
                      name="email"
                      value={formData.email}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all duration-300"
                      placeholder="example@email.com"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div>
                    <label htmlFor="phone" className="block text-gray-700 font-medium mb-2">
                      رقم الهاتف
                    </label>
                    <input
                      type="tel"
                      id="phone"
                      name="phone"
                      value={formData.phone}
                      onChange={handleChange}
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all duration-300"
                      placeholder="+966 XX XXX XXXX"
                    />
                  </div>
                  
                  <div>
                    <label htmlFor="subject" className="block text-gray-700 font-medium mb-2">
                      الموضوع *
                    </label>
                    <select
                      id="subject"
                      name="subject"
                      value={formData.subject}
                      onChange={handleChange}
                      required
                      className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all duration-300"
                    >
                      <option value="">اختر موضوع الرسالة</option>
                      <option value="inquiry">استفسار عام</option>
                      <option value="service">طلب خدمة</option>
                      <option value="support">دعم فني</option>
                      <option value="partnership">شراكة</option>
                      <option value="career">توظيف</option>
                    </select>
                  </div>
                </div>
                
                <div>
                  <label htmlFor="message" className="block text-gray-700 font-medium mb-2">
                    الرسالة *
                  </label>
                  <textarea
                    id="message"
                    name="message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent transition-all duration-300 resize-none"
                    placeholder="اكتب رسالتك هنا..."
                  />
                </div>
                
                <button
                  type="submit"
                  className="w-full btn-primary inline-flex items-center justify-center gap-2"
                >
                  <Send className="w-5 h-5" />
                  إرسال الرسالة
                </button>
              </form>
            </div>
            
            {/* Contact Info */}
            <div className="space-y-8">
              <div>
                <h2 className="text-3xl font-bold text-gray-800 mb-6">معلومات التواصل</h2>
                <p className="text-gray-600 mb-8 leading-relaxed">
                  نحن هنا لمساعدتك والإجابة على جميع استفساراتك. لا تتردد في التواصل معنا 
                  عبر أي من القنوات التالية:
                </p>
              </div>
              
              <div className="space-y-6">
                {contactInfo.map((info, index) => (
                  <div key={index} className="flex items-start gap-4 p-6 bg-gray-50 rounded-xl hover:bg-gray-100 transition-colors duration-300">
                    <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      <info.icon className="w-6 h-6 text-primary-600" />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-gray-800 mb-2">{info.title}</h3>
                      {info.details.map((detail, idx) => (
                        <p key={idx} className="text-gray-600 leading-relaxed">
                          {detail}
                        </p>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
              
              {/* Social Media */}
              <div className="bg-gradient-to-br from-primary-600 to-secondary-600 p-8 rounded-2xl text-white">
                <h3 className="text-2xl font-bold mb-4">تابعنا على وسائل التواصل</h3>
                <p className="text-primary-100 mb-6">
                  ابق على اطلاع بآخر أخبارنا وخدماتنا عبر منصات التواصل الاجتماعي
                </p>
                <div className="flex gap-4">
                  {socialLinks.map(({ icon: Icon, href, label, color }) => (
                    <a
                      key={label}
                      href={href}
                      className={`w-12 h-12 bg-white/20 rounded-xl flex items-center justify-center hover:bg-white/30 transition-all duration-300 transform hover:scale-110 ${color}`}
                      aria-label={label}
                    >
                      <Icon className="w-6 h-6" />
                    </a>
                  ))}
                </div>
              </div>
              
              {/* Quick Response */}
              <div className="bg-green-50 border border-green-200 p-6 rounded-xl">
                <h3 className="text-lg font-bold text-green-800 mb-2">استجابة سريعة</h3>
                <p className="text-green-700 text-sm">
                  نلتزم بالرد على جميع الاستفسارات خلال 24 ساعة من استلامها
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Map Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">موقعنا</h2>
            <p className="text-xl text-gray-600">تفضل بزيارتنا في مكتبنا الرئيسي</p>
          </div>
          
          <div className="bg-white rounded-2xl overflow-hidden shadow-xl">
            <div className="h-96 bg-gray-200 flex items-center justify-center">
              <div className="text-center">
                <MapPin className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">خريطة تفاعلية للموقع</p>
                <p className="text-sm text-gray-500 mt-2">
                  123 شارع الأعمال، الرياض، المملكة العربية السعودية
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-800 mb-4">الأسئلة الشائعة</h2>
            <p className="text-xl text-gray-600">إجابات على أكثر الأسئلة شيوعاً</p>
          </div>
          
          <div className="max-w-3xl mx-auto space-y-6">
            {[
              {
                question: 'كم يستغرق تطوير موقع ويب؟',
                answer: 'يعتمد ذلك على تعقيد المشروع، لكن عادة ما يستغرق من 2-8 أسابيع للمواقع العادية.'
              },
              {
                question: 'هل تقدمون خدمات الصيانة؟',
                answer: 'نعم، نقدم خدمات صيانة شاملة لجميع المشاريع التي ننجزها مع ضمان الدعم الفني.'
              },
              {
                question: 'ما هي تكلفة تطوير تطبيق جوال؟',
                answer: 'تختلف التكلفة حسب المتطلبات والميزات. نقدم عروض أسعار مخصصة لكل مشروع.'
              },
              {
                question: 'هل يمكنني تعديل الموقع بنفسي؟',
                answer: 'نعم، نوفر لوحة تحكم سهلة الاستخدام تمكنك من إدارة المحتوى بسهولة.'
              }
            ].map((faq, index) => (
              <div key={index} className="bg-gray-50 rounded-xl p-6 hover:bg-gray-100 transition-colors duration-300">
                <h3 className="text-lg font-bold text-gray-800 mb-3">{faq.question}</h3>
                <p className="text-gray-600 leading-relaxed">{faq.answer}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};

export default Contact;