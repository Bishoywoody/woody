import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Target, 
  Eye, 
  Lightbulb, 
  Handshake, 
  Users, 
  Trophy,
  ArrowLeft,
  CheckCircle
} from 'lucide-react';

const About = () => {
  const values = [
    {
      icon: Lightbulb,
      title: 'الابتكار',
      description: 'نبحث دائمًا عن أفكار جديدة وطرق مبتكرة لحل المشكلات'
    },
    {
      icon: Handshake,
      title: 'النزاهة',
      description: 'نلتزم بأعلى معايير الأخلاقيات والشفافية في جميع تعاملاتنا'
    },
    {
      icon: Users,
      title: 'العمل الجماعي',
      description: 'نؤمن بقوة التعاون والعمل الجماعي لتحقيق الأهداف المشتركة'
    },
    {
      icon: Trophy,
      title: 'التميز',
      description: 'نسعى دائمًا لتقديم أعلى مستويات الجودة في كل ما نقدمه'
    }
  ];

  const team = [
    {
      name: 'أحمد خالد',
      position: 'المدير التنفيذي',
      image: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=300&q=80',
      bio: 'خبرة 10 سنوات في إدارة المشاريع التقنية'
    },
    {
      name: 'سارة محمد',
      position: 'مديرة التصميم',
      image: 'https://images.unsplash.com/photo-1494790108755-2616b612b786?auto=format&fit=crop&w=300&q=80',
      bio: 'متخصصة في تصميم تجربة المستخدم والواجهات'
    },
    {
      name: 'خالد عبدالله',
      position: 'مدير التطوير',
      image: 'https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?auto=format&fit=crop&w=300&q=80',
      bio: 'خبير في تطوير التطبيقات والمواقع الإلكترونية'
    },
    {
      name: 'نورة سعيد',
      position: 'مديرة التسويق',
      image: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=300&q=80',
      bio: 'متخصصة في التسويق الرقمي ووسائل التواصل الاجتماعي'
    }
  ];

  const milestones = [
    { year: '2010', title: 'تأسيس الشركة', description: 'بدأنا رحلتنا بفريق صغير من المطورين الموهوبين' },
    { year: '2015', title: 'التوسع الأول', description: 'افتتحنا مكتبنا الثاني وضاعفنا حجم الفريق' },
    { year: '2018', title: 'جائزة أفضل شركة تقنية', description: 'حصلنا على جائزة أفضل شركة تقنية ناشئة' },
    { year: '2020', title: 'الوصول لـ 100 عميل', description: 'تجاوزنا حاجز 100 عميل راضي عن خدماتنا' },
    { year: '2023', title: 'التوسع الإقليمي', description: 'بدأنا خدمة العملاء في دول الخليج العربي' }
  ];

  return (
    <div className="pt-20">
      {/* Page Header */}
      <section className="gradient-bg text-white py-16">
        <div className="container mx-auto px-4">
          <div className="max-w-3xl">
            <h1 className="text-4xl md:text-5xl font-bold mb-4">عن شركتنا</h1>
            <p className="text-xl text-gray-100">
              تعرف على قصتنا ورؤيتنا ورسالتنا في تقديم أفضل الحلول التقنية
            </p>
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="animate-slide-up">
              <h2 className="text-4xl font-bold text-gray-800 mb-6">قصتنا</h2>
              <div className="space-y-6 text-gray-600 leading-relaxed">
                <p>
                  تأسست شركتنا في عام 2010 بمجموعة صغيرة من المطورين الموهوبين الذين شاركوا شغفًا مشتركًا 
                  لخلق حلول تقنية مبتكرة. على مر السنين، نما فريقنا وتوسعت خدماتنا، لكن التزامنا بالجودة 
                  والابتكار ظل ثابتًا.
                </p>
                <p>
                  اليوم، نحن فخورون بأننا أصبحنا شركة رائدة في مجال الحلول التقنية، نخدم عملاء من مختلف 
                  القطاعات في جميع أنحاء المنطقة. نؤمن بأن التكنولوجيا يجب أن تكون أداة لتمكين الأعمال 
                  وتحسين الحياة.
                </p>
                <p>
                  هذا الاعتقاد هو ما يدفعنا يوميًا لتقديم أفضل ما لدينا، والسعي المستمر للتطوير والابتكار 
                  في كل مشروع نعمل عليه.
                </p>
              </div>
              
              <div className="mt-8 grid grid-cols-2 gap-6">
                <div className="text-center p-4 bg-primary-50 rounded-lg">
                  <div className="text-3xl font-bold text-primary-600 mb-2">500+</div>
                  <div className="text-gray-600">مشروع مكتمل</div>
                </div>
                <div className="text-center p-4 bg-secondary-50 rounded-lg">
                  <div className="text-3xl font-bold text-secondary-600 mb-2">200+</div>
                  <div className="text-gray-600">عميل راضي</div>
                </div>
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80" 
                alt="فريق العمل" 
                className="w-full rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -left-6 w-32 h-32 bg-primary-600 rounded-2xl flex items-center justify-center text-white">
                <div className="text-center">
                  <div className="text-2xl font-bold">13+</div>
                  <div className="text-sm">سنة خبرة</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Mission & Vision */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 max-w-6xl mx-auto">
            <div className="bg-white p-8 rounded-2xl shadow-lg card-hover">
              <div className="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center mb-6">
                <Target className="w-8 h-8 text-primary-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">رسالتنا</h3>
              <p className="text-gray-600 leading-relaxed">
                تمكين الشركات والأفراد من تحقيق أهدافهم من خلال تقديم حلول تقنية مبتكرة وخدمات 
                استشارية احترافية، مع الحفاظ على أعلى معايير الجودة والكفاءة.
              </p>
            </div>
            
            <div className="bg-white p-8 rounded-2xl shadow-lg card-hover">
              <div className="w-16 h-16 bg-secondary-100 rounded-2xl flex items-center justify-center mb-6">
                <Eye className="w-8 h-8 text-secondary-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-800 mb-4">رؤيتنا</h3>
              <p className="text-gray-600 leading-relaxed">
                أن نكون الشريك التقني المفضل للشركات في المنطقة، المعروف بتميزه في الابتكار والجودة 
                والموثوقية، وأن نساهم في تحويل الأفكار إلى حلول رقمية ناجحة.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Values */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">قيمنا الأساسية</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              القيم التي توجه عملنا وتحدد طريقة تعاملنا مع عملائنا وشركائنا
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <div key={index} className="text-center group">
                <div className="w-20 h-20 bg-primary-100 rounded-2xl flex items-center justify-center mx-auto mb-6 group-hover:bg-primary-600 transition-colors duration-300">
                  <value.icon className="w-10 h-10 text-primary-600 group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-xl font-bold text-gray-800 mb-4">{value.title}</h3>
                <p className="text-gray-600 leading-relaxed">{value.description}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">رحلتنا عبر السنين</h2>
            <p className="text-xl text-gray-600">أهم المحطات في تاريخ شركتنا</p>
          </div>
          
          <div className="max-w-4xl mx-auto">
            {milestones.map((milestone, index) => (
              <div key={index} className="flex items-start mb-12 last:mb-0">
                <div className="flex-shrink-0 w-24 text-center">
                  <div className="w-16 h-16 bg-primary-600 text-white rounded-full flex items-center justify-center font-bold text-lg mx-auto">
                    {milestone.year}
                  </div>
                  {index < milestones.length - 1 && (
                    <div className="w-1 h-16 bg-primary-200 mx-auto mt-4"></div>
                  )}
                </div>
                <div className="flex-1 mr-8 bg-white p-6 rounded-lg shadow-md">
                  <h3 className="text-xl font-bold text-gray-800 mb-2">{milestone.title}</h3>
                  <p className="text-gray-600">{milestone.description}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Team */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">فريقنا المحترف</h2>
            <p className="text-xl text-gray-600">تعرف على الخبراء الذين يقودون نجاح شركتنا</p>
          </div>
          
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
            {team.map((member, index) => (
              <div key={index} className="bg-white rounded-2xl overflow-hidden shadow-lg card-hover group">
                <div className="relative overflow-hidden">
                  <img 
                    src={member.image} 
                    alt={member.name} 
                    className="w-full h-64 object-cover group-hover:scale-110 transition-transform duration-300"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300"></div>
                </div>
                <div className="p-6 text-center">
                  <h3 className="text-xl font-bold text-gray-800 mb-1">{member.name}</h3>
                  <p className="text-primary-600 font-medium mb-3">{member.position}</p>
                  <p className="text-gray-600 text-sm">{member.bio}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl font-bold mb-6">هل تريد الانضمام إلى فريقنا؟</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-gray-100">
            نحن دائمًا نبحث عن مواهب جديدة ومبدعة لتعزيز فريقنا المحترف
          </p>
          <Link to="/contact" className="btn-secondary inline-flex items-center">
            تواصل معنا
            <ArrowLeft className="w-5 h-5 mr-2" />
          </Link>
        </div>
      </section>
    </div>
  );
};

export default About;