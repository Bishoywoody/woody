import React from 'react';
import { Link } from 'react-router-dom';
import { 
  ArrowLeft, 
  Code, 
  Smartphone, 
  Megaphone, 
  Users, 
  Award, 
  CheckCircle,
  Star,
  TrendingUp,
  Shield,
  Zap,
  Globe
} from 'lucide-react';

const Home = () => {
  const services = [
    {
      icon: Code,
      title: 'تصميم المواقع',
      description: 'مواقع ويب احترافية ومتجاوبة مع جميع الأجهزة',
      features: ['تصميم متجاوب', 'سرعة عالية', 'تحسين SEO']
    },
    {
      icon: Smartphone,
      title: 'تطوير التطبيقات',
      description: 'تطبيقات مخصصة لنظامي iOS و Android',
      features: ['تطبيقات أصلية', 'واجهات سهلة', 'أداء ممتاز']
    },
    {
      icon: Megaphone,
      title: 'التسويق الرقمي',
      description: 'حملات تسويقية فعالة لزيادة مبيعاتك',
      features: ['إعلانات مدفوعة', 'تحسين محركات البحث', 'وسائل التواصل']
    }
  ];

  const stats = [
    { number: '500+', label: 'مشروع مكتمل', icon: Award },
    { number: '200+', label: 'عميل راضي', icon: Users },
    { number: '5+', label: 'سنوات خبرة', icon: TrendingUp },
    { number: '24/7', label: 'دعم فني', icon: Shield }
  ];

  const testimonials = [
    {
      name: 'أحمد محمد',
      company: 'شركة التقنية المتقدمة',
      text: 'خدمة ممتازة وفريق محترف. تم تسليم المشروع في الوقت المحدد وبجودة عالية.',
      rating: 5
    },
    {
      name: 'سارة خالد',
      company: 'متجر الأزياء العصرية',
      text: 'ساعدونا في تطوير متجرنا الإلكتروني وزادت مبيعاتنا بنسبة 300%.',
      rating: 5
    },
    {
      name: 'محمد عبدالله',
      company: 'مطعم الذواقة',
      text: 'تطبيق الطلبات الذي طوروه لنا سهل الاستخدام وزاد من كفاءة عملنا.',
      rating: 5
    }
  ];

  return (
    <div className="pt-20">
      {/* Hero Section */}
      <section className="gradient-bg text-white py-20 overflow-hidden relative">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container mx-auto px-4 relative z-10">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div className="animate-slide-up">
              <h1 className="text-4xl md:text-6xl font-bold mb-6 leading-tight">
                حلول تقنية
                <span className="block text-yellow-300">احترافية</span>
                لنجاح أعمالك
              </h1>
              <p className="text-xl mb-8 text-gray-100 leading-relaxed">
                نساعدك في تحويل أفكارك إلى حلول رقمية مبتكرة تدفع نمو عملك إلى الأمام
              </p>
              <div className="flex flex-col sm:flex-row gap-4">
                <Link to="/contact" className="btn-secondary inline-flex items-center justify-center">
                  ابدأ مشروعك الآن
                  <ArrowLeft className="w-5 h-5 mr-2" />
                </Link>
                <Link to="/services" className="btn-outline bg-white/10 border-white text-white hover:bg-white hover:text-primary-600">
                  استكشف خدماتنا
                </Link>
              </div>
            </div>
            
            <div className="relative animate-float">
              <div className="w-full h-96 bg-white/10 rounded-2xl backdrop-blur-sm border border-white/20 p-8 flex items-center justify-center">
                <div className="grid grid-cols-2 gap-4 w-full">
                  <div className="bg-white/20 rounded-lg p-4 flex items-center justify-center">
                    <Code className="w-12 h-12 text-white" />
                  </div>
                  <div className="bg-white/20 rounded-lg p-4 flex items-center justify-center">
                    <Smartphone className="w-12 h-12 text-white" />
                  </div>
                  <div className="bg-white/20 rounded-lg p-4 flex items-center justify-center">
                    <Megaphone className="w-12 h-12 text-white" />
                  </div>
                  <div className="bg-white/20 rounded-lg p-4 flex items-center justify-center">
                    <Globe className="w-12 h-12 text-white" />
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-16 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center group">
                <div className="w-16 h-16 bg-primary-100 rounded-full flex items-center justify-center mx-auto mb-4 group-hover:bg-primary-600 transition-colors duration-300">
                  <stat.icon className="w-8 h-8 text-primary-600 group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-3xl font-bold text-gray-800 mb-2">{stat.number}</h3>
                <p className="text-gray-600">{stat.label}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Services Section */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">خدماتنا المميزة</h2>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto">
              نقدم مجموعة شاملة من الخدمات التقنية المصممة لتلبية احتياجات عملك
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-lg card-hover group">
                <div className="w-16 h-16 bg-primary-100 rounded-2xl flex items-center justify-center mb-6 group-hover:bg-primary-600 transition-colors duration-300">
                  <service.icon className="w-8 h-8 text-primary-600 group-hover:text-white transition-colors duration-300" />
                </div>
                <h3 className="text-2xl font-bold text-gray-800 mb-4">{service.title}</h3>
                <p className="text-gray-600 mb-6 leading-relaxed">{service.description}</p>
                <ul className="space-y-2 mb-6">
                  {service.features.map((feature, idx) => (
                    <li key={idx} className="flex items-center text-gray-600">
                      <CheckCircle className="w-5 h-5 text-green-500 mr-3 flex-shrink-0" />
                      {feature}
                    </li>
                  ))}
                </ul>
                <Link 
                  to="/services" 
                  className="text-primary-600 font-medium hover:text-primary-700 inline-flex items-center group-hover:translate-x-1 transition-transform duration-300"
                >
                  المزيد من التفاصيل
                  <ArrowLeft className="w-4 h-4 mr-2" />
                </Link>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20 bg-white">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div>
              <h2 className="text-4xl font-bold text-gray-800 mb-6">لماذا تختارنا؟</h2>
              <p className="text-xl text-gray-600 mb-8 leading-relaxed">
                نحن نجمع بين الخبرة التقنية والفهم العميق لاحتياجات السوق لنقدم لك حلولاً تقنية تحقق أهدافك
              </p>
              
              <div className="space-y-6">
                {[
                  { icon: Zap, title: 'سرعة في التنفيذ', desc: 'نلتزم بالمواعيد المحددة ونسلم المشاريع في الوقت المناسب' },
                  { icon: Shield, title: 'جودة مضمونة', desc: 'نطبق أعلى معايير الجودة في جميع مراحل العمل' },
                  { icon: Users, title: 'دعم مستمر', desc: 'فريق دعم متاح على مدار الساعة لمساعدتك' }
                ].map((item, index) => (
                  <div key={index} className="flex items-start space-x-4 space-x-reverse">
                    <div className="w-12 h-12 bg-primary-100 rounded-xl flex items-center justify-center flex-shrink-0">
                      <item.icon className="w-6 h-6 text-primary-600" />
                    </div>
                    <div>
                      <h3 className="text-xl font-bold text-gray-800 mb-2">{item.title}</h3>
                      <p className="text-gray-600">{item.desc}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            
            <div className="relative">
              <img 
                src="https://images.unsplash.com/photo-1522071820081-009f0129c71c?auto=format&fit=crop&w=800&q=80" 
                alt="فريق العمل" 
                className="w-full rounded-2xl shadow-2xl"
              />
              <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-primary-600 rounded-2xl flex items-center justify-center">
                <div className="text-center text-white">
                  <div className="text-2xl font-bold">5+</div>
                  <div className="text-sm">سنوات خبرة</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Testimonials */}
      <section className="py-20 bg-gray-50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-800 mb-4">ماذا يقول عملاؤنا</h2>
            <p className="text-xl text-gray-600">آراء عملائنا الكرام في خدماتنا</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {testimonials.map((testimonial, index) => (
              <div key={index} className="bg-white rounded-2xl p-8 shadow-lg card-hover">
                <div className="flex items-center mb-4">
                  {[...Array(testimonial.rating)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 text-yellow-400 fill-current" />
                  ))}
                </div>
                <p className="text-gray-600 mb-6 leading-relaxed italic">"{testimonial.text}"</p>
                <div className="flex items-center">
                  <div className="w-12 h-12 bg-primary-100 rounded-full flex items-center justify-center mr-4">
                    <span className="text-primary-600 font-bold text-lg">
                      {testimonial.name.charAt(0)}
                    </span>
                  </div>
                  <div>
                    <h4 className="font-bold text-gray-800">{testimonial.name}</h4>
                    <p className="text-gray-500 text-sm">{testimonial.company}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 gradient-bg text-white relative overflow-hidden">
        <div className="absolute inset-0 bg-black/10"></div>
        <div className="container mx-auto px-4 text-center relative z-10">
          <h2 className="text-4xl font-bold mb-6">هل أنت مستعد لبدء مشروعك؟</h2>
          <p className="text-xl mb-8 max-w-2xl mx-auto text-gray-100">
            تواصل معنا اليوم واحصل على استشارة مجانية حول كيفية تحويل فكرتك إلى واقع رقمي
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link to="/contact" className="btn-secondary inline-flex items-center justify-center">
              احصل على استشارة مجانية
              <ArrowLeft className="w-5 h-5 mr-2" />
            </Link>
            <Link to="/services" className="btn-outline bg-white/10 border-white text-white hover:bg-white hover:text-primary-600">
              تصفح خدماتنا
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
};

export default Home;