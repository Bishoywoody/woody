import React from 'react';
import { Link } from 'react-router-dom';
import { 
  Globe, 
  MapPin, 
  Phone, 
  Mail, 
  Facebook, 
  Twitter, 
  Linkedin, 
  Instagram,
  ArrowUp
} from 'lucide-react';

const Footer = () => {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <footer className="bg-gray-900 text-white relative">
      {/* Back to top button */}
      <button
        onClick={scrollToTop}
        className="absolute -top-6 left-1/2 transform -translate-x-1/2 bg-primary-600 hover:bg-primary-700 text-white p-3 rounded-full shadow-lg transition-all duration-300 hover:scale-110"
      >
        <ArrowUp className="w-5 h-5" />
      </button>

      <div className="container mx-auto px-4 pt-16 pb-8">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-8">
          {/* Company Info */}
          <div className="space-y-4">
            <div className="flex items-center space-x-3 space-x-reverse">
              <div className="w-10 h-10 bg-gradient-to-br from-primary-500 to-secondary-500 rounded-full flex items-center justify-center">
                <Globe className="w-5 h-5 text-white" />
              </div>
              <h3 className="text-xl font-bold">موقعنا الاحترافي</h3>
            </div>
            <p className="text-gray-300 leading-relaxed">
              نقدم حلولاً تقنية واستشارات احترافية لمساعدة الشركات على النمو والتطور في العصر الرقمي.
            </p>
            <div className="flex space-x-4 space-x-reverse">
              {[
                { icon: Facebook, href: '#', label: 'فيسبوك' },
                { icon: Twitter, href: '#', label: 'تويتر' },
                { icon: Linkedin, href: '#', label: 'لينكد إن' },
                { icon: Instagram, href: '#', label: 'إنستغرام' },
              ].map(({ icon: Icon, href, label }) => (
                <a
                  key={label}
                  href={href}
                  className="w-10 h-10 bg-gray-800 rounded-full flex items-center justify-center hover:bg-primary-600 transition-all duration-300 transform hover:scale-110"
                  aria-label={label}
                >
                  <Icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-lg font-bold mb-6">روابط سريعة</h4>
            <ul className="space-y-3">
              {[
                { name: 'الرئيسية', href: '/' },
                { name: 'عن الشركة', href: '/about' },
                { name: 'الخدمات', href: '/services' },
                { name: 'المدونة', href: '/blog' },
                { name: 'اتصل بنا', href: '/contact' },
              ].map((link) => (
                <li key={link.name}>
                  <Link
                    to={link.href}
                    className="text-gray-300 hover:text-primary-400 transition-colors duration-300 flex items-center group"
                  >
                    <span className="w-2 h-2 bg-primary-500 rounded-full mr-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          {/* Services */}
          <div>
            <h4 className="text-lg font-bold mb-6">خدماتنا</h4>
            <ul className="space-y-3">
              {[
                'تصميم المواقع',
                'تطوير التطبيقات',
                'التسويق الرقمي',
                'الاستشارات التقنية',
                'تحسين محركات البحث',
                'الحلول السحابية',
              ].map((service) => (
                <li key={service}>
                  <a
                    href="#"
                    className="text-gray-300 hover:text-primary-400 transition-colors duration-300 flex items-center group"
                  >
                    <span className="w-2 h-2 bg-primary-500 rounded-full mr-3 opacity-0 group-hover:opacity-100 transition-opacity duration-300"></span>
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-lg font-bold mb-6">تواصل معنا</h4>
            <div className="space-y-4">
              <div className="flex items-start space-x-3 space-x-reverse">
                <div className="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center flex-shrink-0 mt-1">
                  <MapPin className="w-4 h-4" />
                </div>
                <p className="text-gray-300 text-sm leading-relaxed">
                  123 شارع الأعمال، الرياض، المملكة العربية السعودية
                </p>
              </div>
              
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                  <Phone className="w-4 h-4" />
                </div>
                <div className="text-gray-300 text-sm">
                  <p>+966 12 345 6789</p>
                  <p>+966 98 765 4321</p>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 space-x-reverse">
                <div className="w-8 h-8 bg-primary-600 rounded-full flex items-center justify-center">
                  <Mail className="w-4 h-4" />
                </div>
                <div className="text-gray-300 text-sm">
                  <p>info@example.com</p>
                  <p>support@example.com</p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Newsletter */}
        <div className="border-t border-gray-800 pt-8 mb-8">
          <div className="max-w-md mx-auto text-center">
            <h4 className="text-lg font-bold mb-4">اشترك في نشرتنا البريدية</h4>
            <p className="text-gray-300 mb-6">احصل على آخر الأخبار والعروض مباشرة إلى بريدك الإلكتروني</p>
            <form className="flex gap-2">
              <input
                type="email"
                placeholder="بريدك الإلكتروني"
                className="flex-1 px-4 py-2 bg-gray-800 border border-gray-700 rounded-lg focus:outline-none focus:ring-2 focus:ring-primary-500 focus:border-transparent text-white placeholder-gray-400"
              />
              <button
                type="submit"
                className="btn-primary whitespace-nowrap"
              >
                اشتراك
              </button>
            </form>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 pt-6 text-center">
          <p className="text-gray-400 text-sm">
            © 2024 موقعنا الاحترافي. جميع الحقوق محفوظة.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;